﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class QuestManager : MonoBehaviour
{
    int questIndex = 0;

    public static QuestManager instance;

    [Header("📜 모든 퀘스트 데이터")]
    public List<QuestData> allQuestPool = new();
    [Header("🟢 수주 가능 퀘스트")]
    public List<QuestData> availableQuests = new();

    [Header("📝 진행 중 퀘스트")]
    public List<Quest> activeQuests = new();
    [Header("✅ 완료된 퀘스트")]
    public List<Quest> completedQuests = new();


    private void Awake()
    {
        if (instance == null) instance = this;
        else Destroy(gameObject);
    }

    private void Start()
    {

    }

    public void UpdateAvailableQuest()
    {
        foreach (var qd in allQuestPool)
        {
            if (availableQuests.Contains(qd)) continue;
            if (activeQuests.Any(a => a.data.questId == qd.questId)) continue;
            if (completedQuests.Any(c => c.data.questId == qd.questId) && !qd.isRepeatable) continue;

            bool preconditionsMet = qd.requiredCompletedQuestIds.All(
                id => completedQuests.Any(c => c.data.questId == id));

            if (preconditionsMet)
            {
                availableQuests.Add(qd);
                Debug.Log($"🟢 수주 가능 퀘스트 추가됨: {qd.title}");
            }
        }
    }

    public void AddQuest(QuestData data)
    {
        activeQuests.Add(new Quest(data));
    }

    public void ReportEvent(string key, int amount = 1)
    {
        foreach (var quest in activeQuests)
        {
            quest.ReportProgress(key, amount);
        }
    }
}
