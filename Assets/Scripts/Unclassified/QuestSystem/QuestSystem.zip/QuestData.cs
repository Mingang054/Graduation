using System.Collections.Generic;
using UnityEngine;


[System.Serializable]
public class QuestData
{
    public string questId;
    public string title;
    public string description;
    public List<QuestObjective> objectives;
    public QuestReward reward;
    public List<string> requiredCompletedQuestIds;
    public bool isRepeatable;
}


[System.Serializable]
public class QuestReward
{
    public int money;
    public List<string> rewardItemCodes;
    public List<int> rewardItemCount;
}
